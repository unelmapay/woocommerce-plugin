# woocommerce-unelmapay-gateway

For Woocommerce, the idea is users and developers should:
1. Download WooCommerce plugin
2. Install the plugin on their WooCommerce store
3. Enter their unelmapay merchant id on their WooCommerce setting